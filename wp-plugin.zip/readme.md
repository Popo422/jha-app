# JWT Cookie Auth Wordpress Plugin
This plugin simply sets a shared cookie to support shared authentication accross other domains
